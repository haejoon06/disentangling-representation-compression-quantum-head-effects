Quantum Machine Intelligence submission package
Generated from the official Springer Nature December 2024 LaTeX package.

Main file: manuscript.tex
Class: sn-jnl.cls
Reference style: sn-mathphys-ay.bst (author-year, as required by QMI)
Figures: figures/Fig1.png through figures/Fig8.png, with Fig6a.png through Fig6c.png as separate confusion matrices
Editable/vector figure sources: matching SVG files and figures/Fig2.drawio

Compile sequence: pdflatex manuscript; bibtex manuscript; pdflatex manuscript; pdflatex manuscript
The submission system should receive the complete ZIP so all editable source files remain available.
